TANK BETA — Android-проект из HTML-прототипа

ВАЖНО
Это исходный проект для сборки APK, а не готовый APK-файл.
HTML-файл игры помещён в app/src/main/assets/index.html.

ПЕРЕД СБОРКОЙ
Игра использует Three.js с CDN:
https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
Поэтому при первом запуске на устройстве нужен интернет. Если CDN недоступен,
3D-сцена может не загрузиться. В этом проекте разрешён доступ в интернет.

КАК СОБРАТЬ APK НА ПК
1. Установи Android Studio с официального сайта:
   https://developer.android.com/studio
2. Распакуй TankBetaAndroid.zip.
3. В Android Studio выбери Open и укажи папку TankBetaAndroid.
4. Дождись Gradle Sync. Если предложит установить Android SDK Platform 35,
   согласись.
5. Выбери Build > Build Bundle(s) / APK(s) > Build APK(s).
6. После успешной сборки APK обычно находится здесь:
   app/build/outputs/apk/debug/app-debug.apk
7. Перед переименованием/раздачей можешь назвать копию tank.apk.

Для распространения бета-теста используй подписанную сборку (Build > Generate
Signed Bundle / APK), сохрани ключ подписи в безопасном месте и не теряй его.

ПАКЕТ
Application ID: com.tank.beta
Название: Tank Beta
Ориентация: альбомная
Минимальная версия Android: Android 6.0 (API 23)
Версия: 0.1-beta

ПРИМЕЧАНИЕ
Этот контейнер WebView сохраняет исходный HTML без изменения игровой логики.
Перед раздачей протестируй его на телефоне: управление и производительность
могут отличаться от браузера. Для сборки требуется Android Studio/Android SDK.
